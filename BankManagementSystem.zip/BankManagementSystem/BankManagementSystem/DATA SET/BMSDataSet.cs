﻿namespace BankManagementSystem.DATA_SET {
    
    
    public partial class BMSDataSet {
    }
}

namespace BankManagementSystem.DATA_SET.BMSDataSetTableAdapters
{
    
    
    public partial class GetAccountSummaryTableAdapter {
    }
}
